timeMultiplier = 1000

# Just a setter for a global time multiplier value
def setTimeMultiplier(speed):
    global timeMultiplier
    timeMultiplier = speed